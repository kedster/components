
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { ReputationBadge, BadgeDisplayProps } from '../types';

// Hook for fetching badges
export const useBadges = (apiBaseUrl: string = '') => {
  return useQuery<ReputationBadge[]>({
    queryKey: [`${apiBaseUrl}/api/badges`],
    queryFn: async () => {
      const response = await fetch(`${apiBaseUrl}/api/badges`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch badges: ${response.status}`);
      }
      
      return response.json();
    },
    retry: 1,
    staleTime: 300000, // Cache for 5 minutes
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });
};

// Badge display component
export const BadgeDisplay: React.FC<BadgeDisplayProps> = ({
  badges,
  isLoading = false,
  error = null,
  className = '',
  containerClassName = '',
  emptyMessage = 'Building our reputation across the developer community',
  loadingMessage = 'Loading badges...'
}) => {
  if (isLoading) {
    return (
      <div className={`text-center text-gray-400 ${containerClassName}`}>
        <div className="animate-pulse">
          <div className="h-12 w-12 mx-auto mb-2 bg-gray-300 rounded"></div>
          <p className="text-sm">{loadingMessage}</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`text-center text-gray-400 ${containerClassName}`}>
        <div className="h-12 w-12 mx-auto mb-2">⚠️</div>
        <p className="text-sm">Error loading badges</p>
      </div>
    );
  }

  if (!badges || badges.length === 0) {
    return (
      <div className={`text-center text-gray-400 ${containerClassName}`}>
        <div className="h-12 w-12 mx-auto mb-2">🏆</div>
        <p className="text-sm">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className={`flex flex-wrap justify-center items-center gap-8 ${className}`}>
      {badges.map((badge) => (
        <div
          key={badge.id}
          className="flex items-center justify-center reputation-badge"
          dangerouslySetInnerHTML={{ __html: badge.html }}
        />
      ))}
    </div>
  );
};

// Complete badge section component
export const BadgeSection: React.FC<{
  title?: string;
  subtitle?: string;
  apiBaseUrl?: string;
  className?: string;
  containerClassName?: string;
}> = ({
  title = "Trusted & Recognized",
  subtitle = "Building reputation across the developer community",
  apiBaseUrl = '',
  className = '',
  containerClassName = ''
}) => {
  const { data: badges = [], isLoading, error } = useBadges(apiBaseUrl);

  return (
    <section className={`mt-32 ${containerClassName}`}>
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          {title}
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          {subtitle}
        </p>
      </div>

      <div className="flex flex-wrap justify-center items-center gap-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
        <BadgeDisplay
          badges={badges}
          isLoading={isLoading}
          error={error}
          className={className}
        />
      </div>
    </section>
  );
};
