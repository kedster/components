
import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { BadgeAdminProps, ReputationBadge, InsertReputationBadge } from '../types';
import { useBadges } from './BadgeDisplay';

export const BadgeAdmin: React.FC<BadgeAdminProps & { apiBaseUrl?: string }> = ({
  onBadgeAdded,
  onBadgeDeleted,
  className = '',
  apiBaseUrl = ''
}) => {
  const [badgeName, setBadgeName] = useState('');
  const [badgeHtml, setBadgeHtml] = useState('');
  
  const queryClient = useQueryClient();
  const { data: badges = [], isLoading: badgesLoading } = useBadges(apiBaseUrl);

  // Add badge mutation
  const addBadgeMutation = useMutation({
    mutationFn: async (data: InsertReputationBadge) => {
      const response = await fetch(`${apiBaseUrl}/api/admin/badges`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }

      return response.json();
    },
    onSuccess: (newBadge: ReputationBadge) => {
      queryClient.invalidateQueries([`${apiBaseUrl}/api/badges`]);
      setBadgeName('');
      setBadgeHtml('');
      onBadgeAdded?.(newBadge);
    },
    onError: (error: Error) => {
      console.error('Failed to add badge:', error);
      alert(`Failed to add badge: ${error.message}`);
    },
  });

  // Delete badge mutation
  const deleteBadgeMutation = useMutation({
    mutationFn: async (badgeId: string) => {
      const response = await fetch(`${apiBaseUrl}/api/admin/badges/${badgeId}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }

      return response.json();
    },
    onSuccess: (_, badgeId) => {
      queryClient.invalidateQueries([`${apiBaseUrl}/api/badges`]);
      onBadgeDeleted?.(badgeId);
    },
    onError: (error: Error) => {
      console.error('Failed to delete badge:', error);
      alert(`Failed to delete badge: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!badgeName.trim() || !badgeHtml.trim()) return;

    addBadgeMutation.mutate({
      name: badgeName.trim(),
      html: badgeHtml.trim(),
    });
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Add Badge Form */}
      <div className="bg-white p-6 rounded-lg shadow border">
        <h3 className="text-lg font-semibold mb-4">Add New Reputation Badge</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="badgeName" className="block text-sm font-medium text-gray-700 mb-1">
              Badge Name
            </label>
            <input
              id="badgeName"
              type="text"
              value={badgeName}
              onChange={(e) => setBadgeName(e.target.value)}
              placeholder="e.g., Product Hunt, GitHub Stars, etc."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label htmlFor="badgeHtml" className="block text-sm font-medium text-gray-700 mb-1">
              Badge HTML Code
            </label>
            <textarea
              id="badgeHtml"
              value={badgeHtml}
              onChange={(e) => setBadgeHtml(e.target.value)}
              placeholder="Paste the HTML code for your badge here..."
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
              required
            />
          </div>

          {/* Preview */}
          {badgeHtml.trim() && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Preview</label>
              <div className="bg-gray-50 p-4 rounded border">
                <div dangerouslySetInnerHTML={{ __html: badgeHtml }} />
              </div>
            </div>
          )}

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!badgeName.trim() || !badgeHtml.trim() || addBadgeMutation.isPending}
          >
            {addBadgeMutation.isPending ? 'Adding...' : 'Add Badge'}
          </button>
        </form>
      </div>

      {/* Current Badges */}
      <div className="bg-white p-6 rounded-lg shadow border">
        <h3 className="text-lg font-semibold mb-4">Current Badges ({badges.length})</h3>
        
        {badgesLoading ? (
          <div className="text-center py-4">Loading badges...</div>
        ) : badges.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No badges added yet. Add your first reputation badge above.
          </div>
        ) : (
          <div className="space-y-4">
            {badges.map((badge) => (
              <div key={badge.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{badge.name}</h4>
                  <button
                    onClick={() => deleteBadgeMutation.mutate(badge.id)}
                    disabled={deleteBadgeMutation.isPending}
                    className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-50"
                  >
                    Delete
                  </button>
                </div>
                
                {/* Preview */}
                <div className="bg-gray-50 p-3 rounded border">
                  <p className="text-sm text-gray-600 mb-2">Preview:</p>
                  <div dangerouslySetInnerHTML={{ __html: badge.html }} />
                </div>
                
                {/* HTML Code */}
                <div>
                  <p className="text-xs text-gray-500 mb-1">HTML Code:</p>
                  <pre className="bg-gray-100 p-2 rounded text-xs overflow-x-auto">
                    {badge.html}
                  </pre>
                </div>
                
                <div className="text-xs text-gray-500">
                  Added: {new Date(badge.createdAt).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
