
# Badge Loader - Reusable Component Package

A complete, self-contained system for managing and displaying HTML badges/reputation badges in web applications. This package includes both backend API components and React frontend components with full TypeScript support.

## 📦 Package Contents

```
badgeloader/
├── components/           # React components
│   ├── BadgeDisplay.tsx  # Badge display & hooks
│   └── BadgeAdmin.tsx    # Admin management interface
├── backend/              # Backend components
│   ├── api-routes.ts     # Express API routes
│   ├── storage.ts        # Database abstraction layer
│   └── BadgeLoader.ts    # Main backend class
├── types.ts              # TypeScript definitions
├── database-schema.sql   # Database schema
├── examples/             # Integration examples
│   ├── express-setup.js
│   ├── react-setup.tsx
│   └── nextjs-setup.tsx
└── README.md            # This file
```

## 🚀 Quick Start

### 1. Dependencies

Install these packages in your project:

```bash
# Frontend dependencies
npm install @tanstack/react-query react

# Backend dependencies (if using Node.js/Express)
npm install express cors

# Database (choose one)
npm install drizzle-orm @libsql/client  # For SQLite/Turso
npm install drizzle-orm pg              # For PostgreSQL
npm install drizzle-orm mysql2          # For MySQL
```

### 2. Database Setup

Run the SQL schema to create the required table:

```sql
-- Copy and run the contents of database-schema.sql
CREATE TABLE IF NOT EXISTS reputation_badges (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('ab89',abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6)))),
  name TEXT NOT NULL,
  html TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 3. Backend Setup (Express.js)

```typescript
import express from 'express';
import { BadgeLoader } from './badgeloader/backend/BadgeLoader';
import { drizzle } from 'drizzle-orm/libsql';
import { createClient } from '@libsql/client';

const app = express();
app.use(express.json());

// Setup database connection
const client = createClient({ url: 'your-database-url' });
const db = drizzle(client);

// Initialize badge loader
const badgeLoader = new BadgeLoader(db);

// Register API routes
badgeLoader.registerRoutes(app);

app.listen(5000, '0.0.0.0', () => {
  console.log('Server running on port 5000');
});
```

### 4. Frontend Setup (React)

```tsx
import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BadgeSection } from './badgeloader/components/BadgeDisplay';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="App">
        {/* Display badges on your landing page */}
        <BadgeSection 
          title="Our Recognition"
          subtitle="Trusted by the developer community"
          apiBaseUrl="" // Use empty string for same-origin requests
        />
      </div>
    </QueryClientProvider>
  );
}

export default App;
```

## 📚 API Reference

### Backend API Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/badges` | Fetch all badges | No |
| POST | `/api/admin/badges` | Create new badge | Yes |
| DELETE | `/api/admin/badges/:id` | Delete badge | Yes |

### React Components

#### `BadgeDisplay`
Renders a list of badges with loading and error states.

```tsx
import { BadgeDisplay, useBadges } from './badgeloader/components/BadgeDisplay';

function MyComponent() {
  const { data: badges, isLoading, error } = useBadges();
  
  return (
    <BadgeDisplay
      badges={badges || []}
      isLoading={isLoading}
      error={error}
      className="custom-badge-container"
    />
  );
}
```

#### `BadgeSection`
Complete section with title, subtitle, and badge display.

```tsx
<BadgeSection 
  title="Trusted & Recognized"
  subtitle="Building reputation across the developer community"
  apiBaseUrl="https://your-api.com"
  className="my-custom-class"
/>
```

#### `BadgeAdmin`
Admin interface for managing badges (requires authentication).

```tsx
import { BadgeAdmin } from './badgeloader/components/BadgeAdmin';

function AdminPanel() {
  return (
    <BadgeAdmin
      apiBaseUrl="https://your-api.com"
      onBadgeAdded={(badge) => console.log('Added:', badge)}
      onBadgeDeleted={(id) => console.log('Deleted:', id)}
    />
  );
}
```

### Custom Hook: `useBadges`

```tsx
const { data, isLoading, error, refetch } = useBadges(apiBaseUrl);
```

## 🔒 Security & Authentication

The package includes basic auth checking but you need to implement your authentication logic:

```typescript
// In api-routes.ts, modify these methods:
private isAdmin(req: any): boolean {
  // Implement your admin check logic
  return req.user?.role === 'admin';
}

private requireAuth(req: any, res: any, next: any) {
  // Implement your authentication middleware
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}
```

## 🎨 Styling & Customization

### CSS Classes

The components use these CSS classes that you can customize:

```css
/* Badge container */
.reputation-badge {
  /* Your badge styles */
}

/* Loading states */
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

/* Custom badge layout */
.flex.flex-wrap.justify-center.items-center.gap-8 {
  /* Customize badge spacing and layout */
}
```

### Props Customization

All components accept className props for custom styling:

```tsx
<BadgeSection 
  className="custom-badges"
  containerClassName="custom-section"
  title="My Custom Title"
/>
```

## 🔄 Data Flow

1. **Badge Creation**: Admin uses `BadgeAdmin` component → POST to `/api/admin/badges`
2. **Badge Display**: `BadgeSection` uses `useBadges` hook → GET from `/api/badges`
3. **Caching**: React Query caches responses for 5 minutes
4. **Real-time Updates**: Mutations automatically invalidate cache

## 🛠️ Integration Examples

### Next.js Setup

```tsx
// pages/_app.tsx
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient();

export default function App({ Component, pageProps }) {
  return (
    <QueryClientProvider client={queryClient}>
      <Component {...pageProps} />
    </QueryClientProvider>
  );
}

// pages/index.tsx
import { BadgeSection } from '../badgeloader/components/BadgeDisplay';

export default function Home() {
  return (
    <div>
      <h1>Welcome to My App</h1>
      <BadgeSection apiBaseUrl="/api" />
    </div>
  );
}

// pages/api/badges.ts
export { default } from '../../badgeloader/backend/api-routes';
```

### Express.js with Different Databases

```typescript
// PostgreSQL
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

// MySQL
import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);
```

## 📱 Mobile & Responsive

The components are fully responsive and work well on mobile devices:

```tsx
<BadgeSection 
  className="container mx-auto px-4 sm:px-6 lg:px-8"
  // Responsive spacing and layout built-in
/>
```

## 🧪 Testing

```typescript
// Test your badge API
const response = await fetch('/api/badges');
const badges = await response.json();
console.log('Badges loaded:', badges.length);

// Test admin functionality
const newBadge = await fetch('/api/admin/badges', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Test Badge',
    html: '<div>Test HTML</div>'
  })
});
```

## 🚀 Deployment

### Environment Variables

```bash
DATABASE_URL=your-database-connection-string
NODE_ENV=production
```

### Build Optimization

- Badge images are lazy-loaded
- React Query provides efficient caching
- API responses include cache headers
- Bundle size optimized with tree-shaking

## 🔧 Troubleshooting

### Common Issues

**"Failed to fetch badges"**
- Check if `/api/badges` endpoint is accessible
- Verify CORS settings for cross-origin requests
- Check database connection

**"Admin access required"**
- Implement proper authentication in `api-routes.ts`
- Verify user roles and permissions

**Badges not displaying**
- Check HTML content for syntax errors
- Verify badge HTML doesn't conflict with CSP policies
- Check browser console for rendering errors

### Debug Mode

Enable debug logging:

```typescript
const badgeLoader = new BadgeLoader(db, { debug: true });
```

## 📄 License

MIT License - Use freely in your projects.

## 🤝 Contributing

This is a self-contained package. Modify the components and backend logic as needed for your specific use case.

---

**Quick Copy-Paste Setup:**

1. Copy the entire `badgeloader/` directory to your project
2. Install dependencies: `npm install @tanstack/react-query react express`
3. Run the database schema
4. Follow the Express.js or Next.js setup example above
5. Start using `<BadgeSection />` in your components!
