
export interface ReputationBadge {
  id: string;
  name: string;
  html: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface InsertReputationBadge {
  name: string;
  html: string;
}

export interface BadgeLoaderConfig {
  apiBaseUrl?: string;
  adminRequired?: boolean;
  cacheDuration?: number; // seconds
  maxBadges?: number;
  debug?: boolean;
}

export interface BadgeDisplayProps {
  badges: ReputationBadge[];
  isLoading?: boolean;
  error?: Error | null;
  className?: string;
  containerClassName?: string;
  emptyMessage?: string;
  loadingMessage?: string;
}

export interface BadgeAdminProps {
  onBadgeAdded?: (badge: ReputationBadge) => void;
  onBadgeDeleted?: (badgeId: string) => void;
  className?: string;
  apiBaseUrl?: string;
}

export interface BadgeSectionProps {
  title?: string;
  subtitle?: string;
  apiBaseUrl?: string;
  className?: string;
  containerClassName?: string;
}

// Database interfaces for different ORMs
export interface DrizzleDatabase {
  query: {
    reputationBadges: {
      findMany: (options?: any) => Promise<ReputationBadge[]>;
    };
  };
  insert: (table: any) => any;
  delete: (table: any) => any;
  eq: (column: any, value: any) => any;
  desc: (column: any) => any;
}

export interface RawSQLDatabase {
  query: (sql: string, params?: any[]) => Promise<{ rows?: any[]; [key: string]: any }>;
}
