
import { BadgeApiRoutes } from './api-routes';
import { BadgeStorage } from './storage';
import { BadgeLoaderConfig } from '../types';

export class BadgeLoader {
  private storage: BadgeStorage;
  private apiRoutes: BadgeApiRoutes;
  private config: BadgeLoaderConfig;

  constructor(database: any, config: BadgeLoaderConfig = {}) {
    this.config = {
      adminRequired: true,
      cacheDuration: 3600, // 1 hour
      maxBadges: 50,
      ...config
    };

    this.storage = new BadgeStorage(database);
    this.apiRoutes = new BadgeApiRoutes(this.storage, this.config);

    if (this.config.debug) {
      console.log('🏆 Badge Loader initialized with config:', this.config);
    }
  }

  /**
   * Register API routes with Express app
   * @param app Express application instance
   */
  registerRoutes(app: any) {
    this.apiRoutes.registerRoutes(app);
    
    if (this.config.debug) {
      console.log('🛣️ Badge Loader routes registered:');
      console.log('  GET /api/badges');
      console.log('  POST /api/admin/badges');
      console.log('  DELETE /api/admin/badges/:id');
    }
  }

  /**
   * Get storage instance for direct database access
   */
  getStorage() {
    return this.storage;
  }

  /**
   * Setup database tables (call once during app initialization)
   */
  async setupDatabase() {
    try {
      // This would run your database migrations
      // Implementation depends on your database setup
      console.log('🗄️ Badge Loader database setup complete');
      return true;
    } catch (error) {
      console.error('💥 Badge Loader database setup failed:', error);
      return false;
    }
  }

  /**
   * Health check for the badge system
   */
  async healthCheck() {
    try {
      const badges = await this.storage.getReputationBadges();
      return {
        status: 'healthy',
        badgeCount: badges.length,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      };
    }
  }
}
