
import { ReputationBadge, InsertReputationBadge } from '../types';

export interface IBadgeStorage {
  getReputationBadges(): Promise<ReputationBadge[]>;
  createReputationBadge(badge: InsertReputationBadge): Promise<ReputationBadge>;
  deleteReputationBadge(id: string): Promise<boolean>;
}

// Generic database implementation
export class BadgeStorage implements IBadgeStorage {
  constructor(private db: any) {
    if (!db) {
      throw new Error('Database instance is required for BadgeStorage');
    }
  }

  async getReputationBadges(): Promise<ReputationBadge[]> {
    try {
      console.log("🗄️ DATABASE: getReputationBadges() called");
      
      // Generic database query - adapt based on your ORM
      let badges: ReputationBadge[] = [];
      
      if (this.db.query?.reputationBadges) {
        // Drizzle ORM style
        badges = await this.db.query.reputationBadges.findMany({
          orderBy: (badges: any, { desc }: any) => desc(badges.createdAt),
        });
      } else if (this.db.select) {
        // Raw SQL style with select method
        badges = await this.db.select().from(this.reputationBadges).orderBy(this.desc(this.reputationBadges.createdAt));
      } else if (typeof this.db.query === 'function') {
        // Raw SQL query
        const result = await this.db.query('SELECT * FROM reputation_badges ORDER BY created_at DESC');
        badges = result.rows || result;
      } else {
        console.warn('⚠️ Unknown database interface, returning empty array');
        return [];
      }

      console.log(`✅ Found ${badges.length} badges in database`);
      return badges;
    } catch (error) {
      console.error("💥 Database error in getReputationBadges:", error);
      return [];
    }
  }

  async createReputationBadge(badge: InsertReputationBadge): Promise<ReputationBadge> {
    console.log("Creating new badge:", badge.name);
    
    const badgeData = {
      id: this.generateId(),
      ...badge,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    try {
      let created: ReputationBadge;

      if (this.db.insert) {
        // Drizzle ORM style
        [created] = await this.db.insert(this.reputationBadges).values(badgeData).returning();
      } else if (typeof this.db.query === 'function') {
        // Raw SQL
        const result = await this.db.query(
          'INSERT INTO reputation_badges (id, name, html, created_at, updated_at) VALUES (?, ?, ?, ?, ?) RETURNING *',
          [badgeData.id, badgeData.name, badgeData.html, badgeData.createdAt, badgeData.updatedAt]
        );
        created = result.rows?.[0] || result[0];
      } else {
        throw new Error('Unsupported database interface for creating badges');
      }

      console.log("✅ Badge created:", created.id);
      return created;
    } catch (error) {
      console.error("💥 Failed to create badge:", error);
      throw error;
    }
  }

  async deleteReputationBadge(id: string): Promise<boolean> {
    console.log("Deleting badge:", id);
    
    try {
      let result: any;

      if (this.db.delete) {
        // Drizzle ORM style
        result = await this.db.delete(this.reputationBadges)
          .where(this.eq(this.reputationBadges.id, id));
      } else if (typeof this.db.query === 'function') {
        // Raw SQL
        result = await this.db.query('DELETE FROM reputation_badges WHERE id = ?', [id]);
      } else {
        throw new Error('Unsupported database interface for deleting badges');
      }

      const success = (result.rowCount ?? result.changes ?? 0) > 0;
      console.log(`Badge deletion ${success ? 'successful' : 'failed'}`);
      return success;
    } catch (error) {
      console.error("💥 Failed to delete badge:", error);
      return false;
    }
  }

  // Helper methods - adapt these based on your database setup
  private get reputationBadges() {
    // Return your badges table/collection reference
    return this.db.reputationBadges || 'reputation_badges';
  }

  private eq(column: any, value: any) {
    // Return your ORM's equality function
    return this.db.eq ? this.db.eq(column, value) : { column, value };
  }

  private desc(column: any) {
    // Return your ORM's desc function
    return this.db.desc ? this.db.desc(column) : column;
  }

  private generateId(): string {
    // Simple UUID v4 generator
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}
