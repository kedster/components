
import { IBadgeStorage } from './storage';
import { InsertReputationBadge, BadgeLoaderConfig } from '../types';

export class BadgeApiRoutes {
  constructor(
    private storage: IBadgeStorage, 
    private config: BadgeLoaderConfig = {}
  ) {}

  // Public endpoint - get all badges
  async getBadges(req: any, res: any) {
    try {
      // Set cache headers for badges
      const cacheDuration = this.config.cacheDuration || 3600;
      res.setHeader('Cache-Control', `public, max-age=${cacheDuration}, s-maxage=${cacheDuration}`);
      res.setHeader('ETag', '"badges-v1"');

      // Check if client has cached version
      if (req.headers['if-none-match'] === '"badges-v1"') {
        return res.status(304).end();
      }

      if (this.config.debug) {
        console.log("🚀 BADGES API ENDPOINT HIT");
      }
      
      const badges = await this.storage.getReputationBadges();
      
      // Apply max badges limit if configured
      const limitedBadges = this.config.maxBadges 
        ? badges.slice(0, this.config.maxBadges)
        : badges;
      
      if (this.config.debug) {
        console.log(`📤 Sending response with ${limitedBadges.length} badges`);
      }
      
      res.json(limitedBadges);
    } catch (error) {
      console.error("💥 Failed to fetch badges:", error);
      res.status(500).json({ 
        message: "Failed to fetch badges",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Admin endpoint - create badge
  async createBadge(req: any, res: any) {
    try {
      // Check authentication if required
      if (this.config.adminRequired && !this.isAdmin(req)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { name, html }: InsertReputationBadge = req.body;

      if (!name || !html) {
        return res.status(400).json({ message: "Name and HTML are required" });
      }

      // Validate HTML length
      if (html.length > 10000) {
        return res.status(400).json({ message: "HTML content too large (max 10KB)" });
      }

      // Sanitize input
      const sanitizedData = {
        name: this.sanitizeInput(name),
        html: html.trim(),
      };

      const badge = await this.storage.createReputationBadge(sanitizedData);
      
      if (this.config.debug) {
        console.log(`✅ Badge created: ${badge.name}`);
      }
      
      res.json(badge);
    } catch (error) {
      console.error("Failed to create badge:", error);
      res.status(500).json({ 
        message: "Failed to create badge",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Admin endpoint - delete badge
  async deleteBadge(req: any, res: any) {
    try {
      if (this.config.adminRequired && !this.isAdmin(req)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const badgeId = req.params.id;
      
      if (!badgeId) {
        return res.status(400).json({ message: "Badge ID is required" });
      }

      const success = await this.storage.deleteReputationBadge(badgeId);
      
      if (!success) {
        return res.status(404).json({ message: "Badge not found" });
      }

      if (this.config.debug) {
        console.log(`🗑️ Badge deleted: ${badgeId}`);
      }

      res.json({ success: true, message: "Badge deleted successfully" });
    } catch (error) {
      console.error("Failed to delete badge:", error);
      res.status(500).json({ 
        message: "Failed to delete badge",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Register routes with Express app
  registerRoutes(app: any) {
    // Public route
    app.get('/api/badges', this.getBadges.bind(this));
    
    // Admin routes
    if (this.config.adminRequired) {
      app.post('/api/admin/badges', this.requireAuth.bind(this), this.createBadge.bind(this));
      app.delete('/api/admin/badges/:id', this.requireAuth.bind(this), this.deleteBadge.bind(this));
    } else {
      // If admin not required, allow direct access (useful for testing)
      app.post('/api/admin/badges', this.createBadge.bind(this));
      app.delete('/api/admin/badges/:id', this.deleteBadge.bind(this));
    }
  }

  // Helper methods (customize based on your auth system)
  private isAdmin(req: any): boolean {
    // Default implementation - customize this!
    return req.user?.role === 'admin' || 
           req.user?.email?.includes('admin') ||
           req.headers['x-admin-token'] === process.env.ADMIN_TOKEN;
  }

  private requireAuth(req: any, res: any, next: any) {
    // Default implementation - customize this!
    if (!req.user && !req.headers['x-admin-token']) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  }

  private sanitizeInput(input: string): string {
    // Basic input sanitization
    return input.trim().replace(/[<>]/g, '').substring(0, 255);
  }
}
