
import { ReputationBadge, InsertReputationBadge } from './types';

export interface IBadgeStorage {
  getReputationBadges(): Promise<ReputationBadge[]>;
  createReputationBadge(badge: InsertReputationBadge): Promise<ReputationBadge>;
  deleteReputationBadge(id: string): Promise<boolean>;
}

// Example implementation with generic database
export class BadgeStorage implements IBadgeStorage {
  constructor(private db: any) {}

  async getReputationBadges(): Promise<ReputationBadge[]> {
    try {
      console.log("🗄️ DATABASE: getReputationBadges() called");
      
      // Replace with your database query
      const badges = await this.db.query.reputationBadges.findMany({
        orderBy: (badges: any, { desc }: any) => desc(badges.createdAt),
      });

      console.log(`✅ Found ${badges.length} badges in database`);
      return badges;
    } catch (error) {
      console.error("💥 Database error in getReputationBadges:", error);
      return [];
    }
  }

  async createReputationBadge(badge: InsertReputationBadge): Promise<ReputationBadge> {
    console.log("Creating new badge:", badge.name);
    
    const [created] = await this.db.insert(this.reputationBadges).values({
      ...badge,
      createdAt: new Date(),
      updatedAt: new Date(),
    }).returning();
    
    console.log("✅ Badge created:", created.id);
    return created;
  }

  async deleteReputationBadge(id: string): Promise<boolean> {
    console.log("Deleting badge:", id);
    
    const result = await this.db.delete(this.reputationBadges)
      .where(this.eq(this.reputationBadges.id, id));
    
    const success = (result.rowCount ?? 0) > 0;
    console.log(`Badge deletion ${success ? 'successful' : 'failed'}`);
    return success;
  }

  private get reputationBadges() {
    // Return your badges table/collection reference
    return this.db.reputationBadges;
  }

  private eq(column: any, value: any) {
    // Return your ORM's equality function
    return this.db.eq(column, value);
  }
}
