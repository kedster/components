
const express = require('express');
const { BadgeLoader } = require('../index');

// Example Express.js integration
const app = express();

// Your database connection (replace with your actual database)
const database = {
  // Mock database for example
  badges: [],
  query: {
    reputationBadges: {
      findMany: async () => database.badges,
    }
  },
  insert: () => ({
    values: () => ({
      returning: () => [{ id: '1', name: 'Test', html: '<div>Test</div>', createdAt: new Date(), updatedAt: new Date() }]
    })
  }),
  delete: () => ({
    where: () => ({ rowCount: 1 })
  }),
  eq: (a, b) => ({ column: a, value: b })
};

// Initialize badge loader
const badgeLoader = new BadgeLoader(database);

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Add authentication middleware (implement your own)
const requireAuth = (req, res, next) => {
  // Your auth logic here
  req.user = { role: 'admin', email: 'admin@example.com' };
  next();
};

// Register badge routes
badgeLoader.registerRoutes(app);

// Custom route example
app.get('/health', (req, res) => {
  res.json({ status: 'ok', badges: 'loaded' });
});

// Setup database and start server
async function startServer() {
  try {
    await badgeLoader.setupDatabase();
    
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Badge loader server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
