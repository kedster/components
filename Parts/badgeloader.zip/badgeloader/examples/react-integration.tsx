
import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BadgeSection, BadgeAdmin, useBadges } from '../components/BadgeDisplay';

// Setup React Query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
});

// Example: Landing page with badges
function LandingPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="py-20 text-center">
        <h1 className="text-4xl font-bold">My Awesome App</h1>
        <p className="text-xl text-gray-600 mt-4">The best app in the universe</p>
      </header>

      {/* Badge section */}
      <BadgeSection 
        title="Trusted & Recognized"
        subtitle="Building reputation across the developer community"
        apiBaseUrl="" // Use empty string for same-origin requests
        className="container mx-auto px-4"
      />
      
      <footer className="py-20">
        <p className="text-center text-gray-500">© 2024 My App</p>
      </footer>
    </div>
  );
}

// Example: Admin panel for managing badges
function AdminPanel() {
  const { data: badges = [], isLoading } = useBadges();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Badge Management</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Badge admin */}
          <div>
            <BadgeAdmin 
              onBadgeAdded={(badge) => {
                console.log('New badge added:', badge);
                // Could show a toast notification here
              }}
              onBadgeDeleted={(badgeId) => {
                console.log('Badge deleted:', badgeId);
              }}
            />
          </div>
          
          {/* Badge preview */}
          <div className="bg-white p-6 rounded-lg shadow border">
            <h2 className="text-xl font-semibold mb-4">Live Preview</h2>
            {isLoading ? (
              <div className="text-center py-8">Loading...</div>
            ) : badges.length > 0 ? (
              <div className="space-y-4">
                {badges.map((badge) => (
                  <div key={badge.id} className="p-4 bg-gray-50 rounded">
                    <h3 className="font-medium mb-2">{badge.name}</h3>
                    <div dangerouslySetInnerHTML={{ __html: badge.html }} />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No badges yet</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Example: Custom hook usage
function CustomBadgeComponent() {
  const { data: badges, isLoading, error } = useBadges();

  if (isLoading) return <div>Loading badges...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className="flex flex-wrap gap-4">
      {badges?.map((badge) => (
        <div 
          key={badge.id}
          className="transform hover:scale-105 transition-transform"
          dangerouslySetInnerHTML={{ __html: badge.html }}
        />
      ))}
    </div>
  );
}

// Main app component
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="App">
        {/* Routes would go here in a real app */}
        <LandingPage />
      </div>
    </QueryClientProvider>
  );
}

export default App;
