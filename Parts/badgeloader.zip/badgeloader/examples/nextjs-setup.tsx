
// pages/_app.tsx
import type { AppProps } from 'next/app';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState } from 'react';

export default function App({ Component, pageProps }: AppProps) {
  // Create a client instance per request to avoid sharing state between users
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 5 * 60 * 1000, // 5 minutes
        retry: 1,
        refetchOnWindowFocus: false,
      },
    },
  }));

  return (
    <QueryClientProvider client={queryClient}>
      <Component {...pageProps} />
    </QueryClientProvider>
  );
}

// pages/index.tsx - Landing page with badges
import { BadgeSection } from '../badgeloader/components/BadgeDisplay';

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Welcome to Our Platform
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Building amazing products with cutting-edge technology
          </p>
        </div>
      </section>

      {/* Badge Section */}
      <BadgeSection 
        title="Trusted by the Community"
        subtitle="Recognition from leading platforms and developers"
        apiBaseUrl="/api"
        containerClassName="py-16"
      />

      {/* Other content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Features</h2>
          {/* Your feature content */}
        </div>
      </section>
    </div>
  );
}

// pages/admin/badges.tsx - Admin page for managing badges
import { BadgeAdmin } from '../../badgeloader/components/BadgeAdmin';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

export default function BadgeAdminPage() {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check authentication - replace with your auth logic
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/check');
        if (response.ok) {
          const data = await response.json();
          setIsAuthenticated(data.isAdmin);
        }
      } catch (error) {
        console.error('Auth check failed:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
          <p className="text-gray-600 mb-6">You need admin access to manage badges.</p>
          <button 
            onClick={() => router.push('/login')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Badge Management</h1>
          <p className="text-gray-600 mt-2">Manage reputation badges displayed on your website</p>
        </div>

        <BadgeAdmin 
          apiBaseUrl="/api"
          onBadgeAdded={(badge) => {
            console.log('Badge added:', badge);
            // You could add toast notifications here
          }}
          onBadgeDeleted={(badgeId) => {
            console.log('Badge deleted:', badgeId);
          }}
        />
      </div>
    </div>
  );
}

// pages/api/badges.ts - API route for badges
import type { NextApiRequest, NextApiResponse } from 'next';
import { BadgeLoader } from '../../badgeloader/backend/BadgeLoader';
import { drizzle } from 'drizzle-orm/libsql';
import { createClient } from '@libsql/client';

// Initialize database connection
const client = createClient({ 
  url: process.env.DATABASE_URL || 'file:local.db' 
});
const db = drizzle(client);

// Initialize badge loader
const badgeLoader = new BadgeLoader(db, {
  adminRequired: true,
  debug: process.env.NODE_ENV === 'development'
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const badges = await badgeLoader.getStorage().getReputationBadges();
      
      // Set cache headers
      res.setHeader('Cache-Control', 'public, max-age=3600, s-maxage=3600');
      res.json(badges);
    } catch (error) {
      console.error('Failed to fetch badges:', error);
      res.status(500).json({ message: 'Failed to fetch badges' });
    }
  } else {
    res.setHeader('Allow', ['GET']);
    res.status(405).json({ message: 'Method not allowed' });
  }
}

// pages/api/admin/badges.ts - Admin API route
import type { NextApiRequest, NextApiResponse } from 'next';
import { BadgeLoader } from '../../../badgeloader/backend/BadgeLoader';
import { drizzle } from 'drizzle-orm/libsql';
import { createClient } from '@libsql/client';

const client = createClient({ 
  url: process.env.DATABASE_URL || 'file:local.db' 
});
const db = drizzle(client);

const badgeLoader = new BadgeLoader(db);

// Simple auth middleware
function requireAuth(req: NextApiRequest): boolean {
  // Replace with your authentication logic
  const authHeader = req.headers.authorization;
  return authHeader === `Bearer ${process.env.ADMIN_API_KEY}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Check authentication
  if (!requireAuth(req)) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  if (req.method === 'POST') {
    try {
      const { name, html } = req.body;
      
      if (!name || !html) {
        return res.status(400).json({ message: 'Name and HTML are required' });
      }

      const badge = await badgeLoader.getStorage().createReputationBadge({ name, html });
      res.json(badge);
    } catch (error) {
      console.error('Failed to create badge:', error);
      res.status(500).json({ message: 'Failed to create badge' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).json({ message: 'Method not allowed' });
  }
}

// pages/api/admin/badges/[id].ts - Delete badge API route
import type { NextApiRequest, NextApiResponse } from 'next';
import { BadgeLoader } from '../../../../badgeloader/backend/BadgeLoader';
import { drizzle } from 'drizzle-orm/libsql';
import { createClient } from '@libsql/client';

const client = createClient({ 
  url: process.env.DATABASE_URL || 'file:local.db' 
});
const db = drizzle(client);

const badgeLoader = new BadgeLoader(db);

function requireAuth(req: NextApiRequest): boolean {
  const authHeader = req.headers.authorization;
  return authHeader === `Bearer ${process.env.ADMIN_API_KEY}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (!requireAuth(req)) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const { id } = req.query;

  if (req.method === 'DELETE') {
    try {
      const success = await badgeLoader.getStorage().deleteReputationBadge(id as string);
      
      if (!success) {
        return res.status(404).json({ message: 'Badge not found' });
      }

      res.json({ success: true, message: 'Badge deleted' });
    } catch (error) {
      console.error('Failed to delete badge:', error);
      res.status(500).json({ message: 'Failed to delete badge' });
    }
  } else {
    res.setHeader('Allow', ['DELETE']);
    res.status(405).json({ message: 'Method not allowed' });
  }
}

// next.config.js - Next.js configuration
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  
  // Enable if using external images in badges
  images: {
    domains: [
      'example.com', // Add domains for badge images
      'badge-provider.com',
    ],
  },
  
  // Headers for security
  async headers() {
    return [
      {
        source: '/api/badges',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=3600, s-maxage=3600',
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;

// .env.local example
/*
DATABASE_URL=file:local.db
ADMIN_API_KEY=your-secret-admin-key
NODE_ENV=development
*/
