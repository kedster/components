
const express = require('express');
const cors = require('cors');
const { BadgeLoader } = require('../backend/BadgeLoader');

// Example Express.js integration
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Mock database for example (replace with your actual database)
const mockDatabase = {
  badges: [],
  
  // Mock Drizzle-style interface
  query: {
    reputationBadges: {
      findMany: async (options) => {
        return mockDatabase.badges.sort((a, b) => 
          new Date(b.createdAt) - new Date(a.createdAt)
        );
      }
    }
  },
  
  insert: (table) => ({
    values: (data) => ({
      returning: () => {
        const newBadge = {
          id: Date.now().toString(),
          ...data,
          createdAt: new Date(),
          updatedAt: new Date()
        };
        mockDatabase.badges.push(newBadge);
        return [newBadge];
      }
    })
  }),
  
  delete: (table) => ({
    where: (condition) => {
      const index = mockDatabase.badges.findIndex(b => b.id === condition.value);
      if (index > -1) {
        mockDatabase.badges.splice(index, 1);
        return { rowCount: 1 };
      }
      return { rowCount: 0 };
    }
  }),
  
  eq: (column, value) => ({ column, value })
};

// Initialize badge loader
const badgeLoader = new BadgeLoader(mockDatabase, {
  adminRequired: false, // Disable auth for demo
  debug: true,
  maxBadges: 10
});

// Register badge routes
badgeLoader.registerRoutes(app);

// Custom authentication middleware (example)
const requireAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization required' });
  }
  
  // Mock user validation
  req.user = { 
    id: '1', 
    role: 'admin', 
    email: 'admin@example.com' 
  };
  next();
};

// Health check endpoint
app.get('/health', async (req, res) => {
  const health = await badgeLoader.healthCheck();
  res.json(health);
});

// Example protected route
app.get('/api/admin/stats', requireAuth, async (req, res) => {
  const badges = await badgeLoader.getStorage().getReputationBadges();
  res.json({
    totalBadges: badges.length,
    recentBadges: badges.slice(0, 5).map(b => ({ id: b.id, name: b.name }))
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({ 
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? error.message : undefined
  });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Badge Loader server running on port ${PORT}`);
  console.log(`📋 Available endpoints:`);
  console.log(`   GET  http://localhost:${PORT}/api/badges`);
  console.log(`   POST http://localhost:${PORT}/api/admin/badges`);
  console.log(`   GET  http://localhost:${PORT}/health`);
});

module.exports = app;
