
import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BadgeSection, BadgeDisplay, BadgeAdmin, useBadges } from '../components/BadgeDisplay';

// Setup React Query client with optimized defaults
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

// Example 1: Simple badge display on landing page
export function LandingPageExample() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <header className="py-20 text-center">
          <h1 className="text-4xl font-bold text-gray-900">My Awesome App</h1>
          <p className="text-xl text-gray-600 mt-4">The best app in the universe</p>
        </header>

        {/* Badge Section - Complete with title and styling */}
        <BadgeSection 
          title="Trusted & Recognized"
          subtitle="Building reputation across the developer community"
          apiBaseUrl="" // Use empty string for same-origin requests
          className="container mx-auto px-4"
          containerClassName="py-16"
        />

        {/* Footer */}
        <footer className="py-20 text-center">
          <p className="text-gray-500">© 2024 My App</p>
        </footer>
      </div>
    </QueryClientProvider>
  );
}

// Example 2: Custom badge display with hook
export function CustomBadgeExample() {
  const { data: badges = [], isLoading, error, refetch } = useBadges();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <div className="text-red-600 mb-4">Error loading badges: {error.message}</div>
        <button 
          onClick={() => refetch()}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Our Badges ({badges.length})</h2>
        <button 
          onClick={() => refetch()}
          className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300"
        >
          Refresh
        </button>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {badges.map((badge) => (
          <div 
            key={badge.id}
            className="bg-white p-6 rounded-lg shadow border hover:shadow-lg transition-shadow"
          >
            <h3 className="font-semibold mb-3">{badge.name}</h3>
            <div 
              className="flex justify-center"
              dangerouslySetInnerHTML={{ __html: badge.html }}
            />
            <p className="text-xs text-gray-500 mt-3">
              Added: {new Date(badge.createdAt).toLocaleDateString()}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

// Example 3: Admin panel for managing badges
export function AdminPanelExample() {
  const { data: badges = [], isLoading } = useBadges();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Badge Management</h1>
          
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            {/* Badge Admin Interface */}
            <div>
              <BadgeAdmin 
                onBadgeAdded={(badge) => {
                  console.log('New badge added:', badge);
                  // You could show a toast notification here
                  alert(`Badge "${badge.name}" added successfully!`);
                }}
                onBadgeDeleted={(badgeId) => {
                  console.log('Badge deleted:', badgeId);
                  alert('Badge deleted successfully!');
                }}
              />
            </div>
            
            {/* Live Preview */}
            <div className="bg-white p-6 rounded-lg shadow border">
              <h2 className="text-xl font-semibold mb-4">Live Preview</h2>
              {isLoading ? (
                <div className="text-center py-8">Loading...</div>
              ) : badges.length > 0 ? (
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 mb-4">
                    This is how badges appear on your website:
                  </p>
                  <BadgeDisplay
                    badges={badges}
                    className="bg-gray-50 p-4 rounded border"
                  />
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">
                  No badges yet. Add your first badge to see the preview.
                </p>
              )}
            </div>
          </div>

          {/* Badge Statistics */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-6 rounded-lg shadow border text-center">
              <div className="text-3xl font-bold text-blue-600">{badges.length}</div>
              <div className="text-gray-600">Total Badges</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow border text-center">
              <div className="text-3xl font-bold text-green-600">
                {badges.filter(b => b.createdAt > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length}
              </div>
              <div className="text-gray-600">Added This Week</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow border text-center">
              <div className="text-3xl font-bold text-purple-600">
                {badges.reduce((acc, b) => acc + b.html.length, 0)}
              </div>
              <div className="text-gray-600">Total HTML Characters</div>
            </div>
          </div>
        </div>
      </div>
    </QueryClientProvider>
  );
}

// Example 4: Minimal badge display for sidebars
export function SidebarBadgesExample() {
  const { data: badges = [], isLoading } = useBadges();

  if (isLoading || badges.length === 0) return null;

  return (
    <div className="space-y-3">
      <h3 className="font-semibold text-sm text-gray-600 uppercase tracking-wide">
        Recognition
      </h3>
      <div className="space-y-2">
        {badges.slice(0, 3).map((badge) => (
          <div 
            key={badge.id}
            className="transform hover:scale-105 transition-transform"
            dangerouslySetInnerHTML={{ __html: badge.html }}
          />
        ))}
      </div>
    </div>
  );
}

// Main App component demonstrating setup
export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="App">
        {/* Choose one of the examples above */}
        <LandingPageExample />
      </div>
    </QueryClientProvider>
  );
}

// Export all examples for easy importing
export {
  LandingPageExample,
  CustomBadgeExample,
  AdminPanelExample,
  SidebarBadgesExample
};
