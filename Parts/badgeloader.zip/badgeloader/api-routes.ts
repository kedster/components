
import { IBadgeStorage } from './storage';
import { InsertReputationBadge } from './types';

export class BadgeApiRoutes {
  constructor(private storage: IBadgeStorage) {}

  // Public endpoint - get all badges
  async getBadges(req: any, res: any) {
    try {
      // Set cache headers for badges (cache for 1 hour)
      res.setHeader('Cache-Control', 'public, max-age=3600, s-maxage=3600');
      res.setHeader('ETag', '"badges-v1"');

      // Check if client has cached version
      if (req.headers['if-none-match'] === '"badges-v1"') {
        return res.status(304).end();
      }

      console.log("🚀 BADGES API ENDPOINT HIT");
      
      const badges = await this.storage.getReputationBadges();
      
      console.log(`📤 Sending response with ${badges.length} badges`);
      res.json(badges);
    } catch (error) {
      console.error("💥 Failed to fetch badges:", error);
      res.status(500).json({ 
        message: "Failed to fetch badges",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Admin endpoint - create badge
  async createBadge(req: any, res: any) {
    try {
      // Check authentication (implement your auth logic)
      if (!this.isAdmin(req)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { name, html }: InsertReputationBadge = req.body;

      if (!name || !html) {
        return res.status(400).json({ message: "Name and HTML are required" });
      }

      // Sanitize input
      const sanitizedData = {
        name: this.sanitizeInput(name),
        html: html.trim(),
      };

      const badge = await this.storage.createReputationBadge(sanitizedData);
      res.json(badge);
    } catch (error) {
      console.error("Failed to create badge:", error);
      res.status(500).json({ 
        message: "Failed to create badge",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Admin endpoint - delete badge
  async deleteBadge(req: any, res: any) {
    try {
      if (!this.isAdmin(req)) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const badgeId = req.params.id;
      const success = await this.storage.deleteReputationBadge(badgeId);
      
      if (!success) {
        return res.status(404).json({ message: "Badge not found" });
      }

      res.json({ success: true, message: "Badge deleted successfully" });
    } catch (error) {
      console.error("Failed to delete badge:", error);
      res.status(500).json({ 
        message: "Failed to delete badge",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  // Register routes with Express app
  registerRoutes(app: any) {
    // Public route
    app.get('/api/badges', this.getBadges.bind(this));
    
    // Admin routes (add your auth middleware)
    app.post('/api/admin/badges', this.requireAuth.bind(this), this.createBadge.bind(this));
    app.delete('/api/admin/badges/:id', this.requireAuth.bind(this), this.deleteBadge.bind(this));
  }

  // Helper methods (implement based on your auth system)
  private isAdmin(req: any): boolean {
    // Implement your admin check logic
    return req.user?.role === 'admin' || req.user?.email === 'admin@example.com';
  }

  private requireAuth(req: any, res: any, next: any) {
    // Implement your authentication middleware
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  }

  private sanitizeInput(input: string): string {
    // Basic input sanitization
    return input.trim().replace(/[<>]/g, '');
  }
}

// Usage example:
// const badgeRoutes = new BadgeApiRoutes(badgeStorage);
// badgeRoutes.registerRoutes(app);
