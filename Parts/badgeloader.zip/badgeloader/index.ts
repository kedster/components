
// Main exports for the Badge Loader package

// Types
export type { 
  ReputationBadge, 
  InsertReputationBadge, 
  BadgeLoaderConfig,
  BadgeDisplayProps,
  BadgeAdminProps,
  BadgeSectionProps,
  DrizzleDatabase,
  RawSQLDatabase
} from './types';

// Backend Components
export { IBadgeStorage, BadgeStorage } from './backend/storage';
export { BadgeApiRoutes } from './backend/api-routes';
export { BadgeLoader } from './backend/BadgeLoader';

// React Components
export { 
  BadgeDisplay, 
  BadgeSection, 
  useBadges 
} from './components/BadgeDisplay';
export { BadgeAdmin } from './components/BadgeAdmin';

// Package information
export const version = '1.0.0';
export const name = 'badge-loader';

// Utility functions
export const createBadgeLoader = (database: any, config?: BadgeLoaderConfig) => {
  return new BadgeLoader(database, config);
};

// Default configuration
export const defaultConfig: BadgeLoaderConfig = {
  adminRequired: true,
  cacheDuration: 3600, // 1 hour
  maxBadges: 50,
  debug: false
};

// Quick setup helpers
export const setupExpress = (app: any, database: any, config?: BadgeLoaderConfig) => {
  const badgeLoader = new BadgeLoader(database, config);
  badgeLoader.registerRoutes(app);
  return badgeLoader;
};

export const createQueryClient = () => {
  const { QueryClient } = require('@tanstack/react-query');
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 5 * 60 * 1000, // 5 minutes
        retry: 1,
        refetchOnWindowFocus: false,
      },
    },
  });
};
