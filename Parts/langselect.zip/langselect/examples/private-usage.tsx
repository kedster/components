
import React from 'react';
import { useLanguage, LanguageSelector } from '../index';

// Example 1: Private Dashboard Header
function DashboardHeader() {
  const { t } = useLanguage();

  return (
    <header className="h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 lg:px-6">
      {/* Left side - Menu toggle and language selector */}
      <div className="flex items-center space-x-2">
        <button className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <LanguageSelector variant="ghost" size="sm" />
      </div>

      {/* Right side - User menu */}
      <div className="flex items-center space-x-4">
        <button className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white">
          <span className="sr-only">Notifications</span>
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
          </svg>
        </button>
        
        <div className="flex items-center space-x-2">
          <img className="w-8 h-8 rounded-full" src="/avatar.jpg" alt="User" />
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">John Doe</span>
        </div>
      </div>
    </header>
  );
}

// Example 2: Settings Page with Language Configuration
function LanguageSettings() {
  const { language, setLanguage, t } = useLanguage();

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  ];

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
        {t.settings.general.language.label}
      </h3>
      <p className="text-gray-600 dark:text-gray-300 mb-6">
        {t.settings.general.language.description}
      </p>

      {/* Custom language selector for settings */}
      <div className="space-y-3">
        {languages.map((lang) => (
          <label key={lang.code} className="flex items-center space-x-3 cursor-pointer">
            <input
              type="radio"
              name="language"
              value={lang.code}
              checked={language === lang.code}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
            />
            <span className="text-2xl">{lang.flag}</span>
            <span className="text-gray-900 dark:text-white font-medium">{lang.name}</span>
            {language === lang.code && (
              <span className="text-blue-600 text-sm">✓ {t.common.selected || 'Selected'}</span>
            )}
          </label>
        ))}
      </div>

      {/* Quick selector dropdown */}
      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Quick Selector:
        </label>
        <LanguageSelector variant="outline" size="default" className="w-full max-w-xs" />
      </div>
    </div>
  );
}

// Example 3: Sidebar with Translations
function Sidebar() {
  const { t } = useLanguage();
  const [isCollapsed, setIsCollapsed] = React.useState(false);

  const menuItems = [
    { key: 'dashboard', icon: '📊', label: t.app.sidebar.dashboard, href: '/dashboard' },
    { key: 'domains', icon: '🌐', label: t.app.sidebar.domains, href: '/domains' },
    { key: 'dns-records', icon: '📝', label: t.app.sidebar.dnsRecords, href: '/dns-records' },
    { key: 'analytics', icon: '📈', label: t.app.sidebar.analytics, href: '/analytics' },
    { key: 'settings', icon: '⚙️', label: t.app.sidebar.settings, href: '/settings' },
  ];

  return (
    <aside className={`bg-gray-900 text-white transition-all duration-300 ${isCollapsed ? 'w-16' : 'w-64'}`}>
      <div className="p-4">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <h2 className="text-xl font-bold">DNSRedo</h2>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 rounded-md hover:bg-gray-800"
          >
            {isCollapsed ? '→' : '←'}
          </button>
        </div>
      </div>

      <nav className="mt-8">
        {menuItems.map((item) => (
          <a
            key={item.key}
            href={item.href}
            className="flex items-center px-4 py-3 text-gray-300 hover:bg-gray-800 hover:text-white transition-colors"
          >
            <span className="text-lg">{item.icon}</span>
            {!isCollapsed && (
              <span className="ml-3">{item.label}</span>
            )}
          </a>
        ))}
      </nav>

      {/* Language selector in sidebar footer */}
      {!isCollapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <LanguageSelector variant="ghost" size="sm" className="w-full text-white" />
        </div>
      )}
    </aside>
  );
}

// Example 4: Complete Private App Layout
function PrivateAppLayout({ children }: { children: React.ReactNode }) {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="flex">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <DashboardHeader />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 lg:p-6">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}

export { DashboardHeader, LanguageSettings, Sidebar, PrivateAppLayout };
