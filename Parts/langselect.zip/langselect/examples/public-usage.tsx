
import React from 'react';
import { LanguageProvider, LanguageSelector, useLanguage } from '../index';

// Example 1: Simple Landing Page with Language Selector
function LandingPage() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="flex items-center justify-between p-6 bg-white shadow-sm">
        <div className="text-xl font-bold">Your Logo</div>
        
        {/* Language selector in top navigation */}
        <div className="flex items-center space-x-4">
          <a href="/blog" className="text-gray-600 hover:text-gray-900">
            {t.nav.blog}
          </a>
          <LanguageSelector variant="outline" size="sm" />
        </div>
      </nav>

      {/* Hero Section */}
      <section className="px-6 py-20 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          {t.hero.title}
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          {t.hero.description}
        </p>
        <button className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700">
          {t.hero.ctaButton}
        </button>
        <p className="text-sm text-gray-500 mt-4">
          {t.hero.noCreditCard}
        </p>
      </section>

      {/* Features Section */}
      <section className="px-6 py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">
            {t.features.title}
          </h2>
          <p className="text-xl text-gray-600 text-center mb-12">
            {t.features.subtitle}
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">
                {t.features.centralizedDns.title}
              </h3>
              <p className="text-gray-600">
                {t.features.centralizedDns.description}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">
                {t.features.smartBackups.title}
              </h3>
              <p className="text-gray-600">
                {t.features.smartBackups.description}
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">
                {t.features.propagationTracking.title}
              </h3>
              <p className="text-gray-600">
                {t.features.propagationTracking.description}
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// Example 2: Main App with Public Routes
function PublicApp() {
  return (
    <LanguageProvider defaultLanguage="en" storageKey="myapp-language">
      <div className="app">
        {/* Router would go here */}
        <LandingPage />
        
        {/* Other public routes like /pricing, /blog, etc. */}
      </div>
    </LanguageProvider>
  );
}

// Example 3: Footer with Language Selector
function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-gray-400">© 2024 Your Company. All rights reserved.</p>
          </div>
          
          {/* Language selector in footer */}
          <div className="flex items-center space-x-4">
            <span className="text-gray-400">Language:</span>
            <LanguageSelector variant="ghost" size="sm" className="text-white" />
          </div>
        </div>
      </div>
    </footer>
  );
}

export { PublicApp, LandingPage, Footer };
