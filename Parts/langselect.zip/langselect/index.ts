
// Main exports
export { LanguageProvider, useLanguage } from './hooks/useLanguage';
export { default as LanguageSelector } from './components/LanguageSelector';

// Type exports
export type { 
  Language, 
  LanguageStrings, 
  LanguageContextType, 
  LanguageSelectorProps 
} from './types';

// Translation exports
export { getTranslation } from './translations';

// Component exports for flexibility
export { LanguageSelector } from './components/LanguageSelector';
