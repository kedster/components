
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getTranslation, type LanguageStrings } from '../translations';
import { LanguageContextType } from '../types';

export const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

interface LanguageProviderProps {
  children: ReactNode;
  defaultLanguage?: string;
  storageKey?: string;
}

export function LanguageProvider({ 
  children, 
  defaultLanguage = 'en',
  storageKey = 'dnsredo-language'
}: LanguageProviderProps): JSX.Element {
  const [language, setLanguageState] = useState(() => {
    // Check both possible localStorage keys for compatibility
    const savedLang = localStorage.getItem(storageKey) || 
                     localStorage.getItem('selectedLanguage') || 
                     defaultLanguage;
    return savedLang;
  });

  const setLanguage = (lang: string) => {
    setLanguageState(lang);
    // Store in both keys for compatibility
    localStorage.setItem(storageKey, lang);
    localStorage.setItem('selectedLanguage', lang);
    
    // Update document language attribute for SEO
    document.documentElement.lang = lang;
    
    // Update meta tags
    const metaLang = document.querySelector('meta[name="language"]');
    if (metaLang) {
      metaLang.setAttribute('content', lang);
    }

    // Dispatch custom event for immediate updates without page reload
    window.dispatchEvent(new CustomEvent('languageChanged', { 
      detail: { language: lang } 
    }));
  };

  // Set initial document language and listen for storage changes
  useEffect(() => {
    document.documentElement.lang = language;
    const metaLang = document.querySelector('meta[name="language"]');
    if (metaLang) {
      metaLang.setAttribute('content', language);
    }

    // Listen for storage changes from other tabs/pages
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === storageKey || e.key === 'selectedLanguage') {
        if (e.newValue && e.newValue !== language) {
          setLanguageState(e.newValue);
        }
      }
    };

    // Listen for custom language change events
    const handleLanguageChange = (e: CustomEvent) => {
      if (e.detail.language && e.detail.language !== language) {
        setLanguageState(e.detail.language);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('languageChanged', handleLanguageChange as EventListener);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('languageChanged', handleLanguageChange as EventListener);
    };
  }, [language, storageKey]);

  const t = getTranslation(language);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}
