
import { LanguageStrings } from '../types';

const translations: Record<string, LanguageStrings> = {
  en: {
    nav: {
      wiki: "Wiki",
      blog: "Blog",
      getStarted: "Get Started"
    },
    hero: {
      title: "Intelligent DNS Management Platform",
      subtitle: "Centralized DNS Control",
      description: "Manage all your domains from one powerful dashboard with AI-powered insights, automated backups, and real-time propagation tracking.",
      ctaButton: "Start Free Trial",
      noCreditCard: "No credit card required"
    },
    features: {
      title: "Everything you need for DNS management",
      subtitle: "Powerful features to manage your domains efficiently",
      centralizedDns: {
        title: "Centralized DNS Control",
        description: "Manage all your domains from one unified dashboard"
      },
      smartBackups: {
        title: "Smart Backups",
        description: "Automated snapshots with intelligent recovery options"
      },
      propagationTracking: {
        title: "Propagation Tracking",
        description: "Real-time monitoring of DNS changes across global servers"
      },
      aiDnsManagement: {
        title: "AI DNS Management",
        description: "Intelligent recommendations and automated optimizations"
      },
      teamReady: {
        title: "Team Ready",
        description: "Collaborative features for teams of all sizes"
      },
      apiSupport: {
        title: "API Support",
        description: "Full REST API for programmatic control"
      }
    },
    pricing: {
      title: "Simple, transparent pricing",
      subtitle: "Choose the plan that fits your needs",
      freePlan: {
        title: "Free",
        price: "$0/month",
        features: [
          "Up to 3 domains",
          "Basic DNS management",
          "Community support"
        ],
        button: "Get Started"
      },
      premiumPlan: {
        title: "Premium",
        price: "$19/month",
        popular: "Most Popular",
        features: [
          "Unlimited domains",
          "AI-powered insights",
          "Priority support",
          "Advanced analytics"
        ],
        button: "Start Free Trial"
      }
    },
    app: {
      sidebar: {
        dashboard: "Dashboard",
        domains: "Domains",
        domainBackups: "Domain Backups",
        dnsRecords: "DNS Records",
        propagation: "Propagation",
        analytics: "Analytics",
        aiDrDns: "AI Dr. DNS",
        settings: "Settings",
        help: "Help",
        pricing: "Pricing",
        signOut: "Sign Out"
      },
      dashboard: {
        title: "Dashboard",
        totalDomains: "Total Domains",
        totalRecords: "Total Records",
        propagating: "Propagating",
        errors: "Errors",
        welcomeBack: "Welcome back"
      },
      settings: {
        title: "Settings",
        tabs: {
          general: "General",
          ai: "AI Assistant",
          dns: "DNS",
          notifications: "Notifications",
          security: "Security"
        },
        general: {
          title: "General Settings",
          darkMode: { label: "Dark Mode", description: "Enable dark mode" },
          autoRefresh: { label: "Auto Refresh", description: "Automatically refresh data" },
          refreshInterval: { label: "Interval (seconds)", description: "How often to refresh" },
          language: { label: "Language", description: "Choose your language" },
          timezone: { label: "Timezone" }
        },
        ai: {
          title: "AI Assistant",
          description: "Configure AI Assistant",
          managementButton: "Manage AI Assistant"
        },
        dns: {
          title: "DNS Settings",
          defaultTtl: { label: "Default TTL", description: "Default TTL in seconds" },
          propagationMonitoring: {
            title: "Propagation Monitoring",
            configureButton: "Configure",
            description: ({ count }) => `Monitoring ${count} servers`
          }
        },
        notifications: {
          title: "Notifications",
          enableNotifications: { label: "Enable", description: "Receive notifications" },
          notificationTypes: {
            title: "Types",
            dnsChanges: "DNS Changes",
            propagationFailures: "Propagation Failures",
            aiRecommendations: "AI Recommendations",
            securityAlerts: "Security Alerts"
          }
        },
        security: {
          title: "Security",
          twoFactor: { label: "Two-Factor Authentication", description: "Enable 2FA" },
          sessionTimeout: { label: "Session Timeout", description: "Auto logout time" },
          loginNotifications: { label: "Login Notifications", description: "Email on login" }
        }
      }
    },
    common: {
      save: "Save",
      cancel: "Cancel",
      delete: "Delete",
      edit: "Edit",
      add: "Add",
      loading: "Loading...",
      error: "Error",
      success: "Success",
      confirm: "Confirm",
      yes: "Yes",
      no: "No"
    }
  },
  es: {
    nav: {
      wiki: "Wiki",
      blog: "Blog",
      getStarted: "Comenzar"
    },
    hero: {
      title: "Plataforma Inteligente de Gestión DNS",
      subtitle: "Control DNS Centralizado",
      description: "Gestiona todos tus dominios desde un panel potente con insights impulsados por IA, copias de seguridad automatizadas y seguimiento de propagación en tiempo real.",
      ctaButton: "Prueba Gratuita",
      noCreditCard: "No se requiere tarjeta de crédito"
    },
    features: {
      title: "Todo lo que necesitas para la gestión DNS",
      subtitle: "Características potentes para gestionar tus dominios eficientemente",
      centralizedDns: {
        title: "Control DNS Centralizado",
        description: "Gestiona todos tus dominios desde un panel unificado"
      },
      smartBackups: {
        title: "Copias Inteligentes",
        description: "Instantáneas automatizadas con opciones de recuperación inteligentes"
      },
      propagationTracking: {
        title: "Seguimiento de Propagación",
        description: "Monitoreo en tiempo real de cambios DNS en servidores globales"
      },
      aiDnsManagement: {
        title: "Gestión DNS con IA",
        description: "Recomendaciones inteligentes y optimizaciones automatizadas"
      },
      teamReady: {
        title: "Listo para Equipos",
        description: "Características colaborativas para equipos de todos los tamaños"
      },
      apiSupport: {
        title: "Soporte API",
        description: "API REST completa para control programático"
      }
    },
    pricing: {
      title: "Precios simples y transparentes",
      subtitle: "Elige el plan que se adapte a tus necesidades",
      freePlan: {
        title: "Gratis",
        price: "$0/mes",
        features: [
          "Hasta 3 dominios",
          "Gestión DNS básica",
          "Soporte comunitario"
        ],
        button: "Comenzar"
      },
      premiumPlan: {
        title: "Premium",
        price: "$19/mes",
        popular: "Más Popular",
        features: [
          "Dominios ilimitados",
          "Insights impulsados por IA",
          "Soporte prioritario",
          "Analíticas avanzadas"
        ],
        button: "Prueba Gratuita"
      }
    },
    app: {
      sidebar: {
        dashboard: "Panel",
        domains: "Dominios",
        domainBackups: "Copias de Dominios",
        dnsRecords: "Registros DNS",
        propagation: "Propagación",
        analytics: "Analíticas",
        aiDrDns: "Dr. DNS IA",
        settings: "Configuración",
        help: "Ayuda",
        pricing: "Precios",
        signOut: "Cerrar Sesión"
      },
      dashboard: {
        title: "Panel",
        totalDomains: "Dominios Totales",
        totalRecords: "Registros Totales",
        propagating: "Propagando",
        errors: "Errores",
        welcomeBack: "Bienvenido de vuelta"
      },
      settings: {
        title: "Configuración",
        tabs: {
          general: "General",
          ai: "Asistente IA",
          dns: "DNS",
          notifications: "Notificaciones",
          security: "Seguridad"
        },
        general: {
          title: "Configuración General",
          darkMode: { label: "Modo Oscuro", description: "Activar modo oscuro" },
          autoRefresh: { label: "Actualización Automática", description: "Actualizar datos automáticamente" },
          refreshInterval: { label: "Intervalo (segundos)", description: "Frecuencia de actualización" },
          language: { label: "Idioma", description: "Elige tu idioma" },
          timezone: { label: "Zona Horaria" }
        },
        ai: {
          title: "Asistente IA",
          description: "Configurar Asistente IA",
          managementButton: "Gestionar Asistente IA"
        },
        dns: {
          title: "Configuración DNS",
          defaultTtl: { label: "TTL Predeterminado", description: "TTL predeterminado en segundos" },
          propagationMonitoring: {
            title: "Monitoreo de Propagación",
            configureButton: "Configurar",
            description: ({ count }) => `Monitoreando ${count} servidores`
          }
        },
        notifications: {
          title: "Notificaciones",
          enableNotifications: { label: "Activar", description: "Recibir notificaciones" },
          notificationTypes: {
            title: "Tipos",
            dnsChanges: "Cambios DNS",
            propagationFailures: "Fallas de Propagación",
            aiRecommendations: "Recomendaciones IA",
            securityAlerts: "Alertas de Seguridad"
          }
        },
        security: {
          title: "Seguridad",
          twoFactor: { label: "Autenticación de Dos Factores", description: "Activar 2FA" },
          sessionTimeout: { label: "Tiempo de Sesión", description: "Tiempo de cierre automático" },
          loginNotifications: { label: "Notificaciones de Inicio", description: "Email al iniciar sesión" }
        }
      }
    },
    common: {
      save: "Guardar",
      cancel: "Cancelar",
      delete: "Eliminar",
      edit: "Editar",
      add: "Agregar",
      loading: "Cargando...",
      error: "Error",
      success: "Éxito",
      confirm: "Confirmar",
      yes: "Sí",
      no: "No"
    }
  }
  // Add more languages here following the same pattern
};

export function getTranslation(language: string): LanguageStrings {
  return translations[language] || translations.en;
}

export type { LanguageStrings };
