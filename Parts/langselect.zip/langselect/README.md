
# Language Selector Module

A complete, reusable internationalization (i18n) system for React applications with persistent language selection and translation management.

## Quick Start

### 1. Install Dependencies
```bash
npm install react
```

### 2. Copy Module Files
Copy the entire `langselect` folder to your project.

### 3. Setup Translation Files
Create your translation files in the `translations` folder or modify the existing ones.

### 4. Integration

#### Public Routes (Landing Pages, Marketing)
```tsx
import { LanguageProvider, LanguageSelector } from './langselect';

function PublicApp() {
  return (
    <LanguageProvider>
      <div className="app">
        {/* Navigation with language selector */}
        <nav className="flex justify-between items-center p-4">
          <div className="logo">Your Logo</div>
          <LanguageSelector variant="outline" size="sm" />
        </nav>
        
        {/* Your content using translations */}
        <YourContent />
      </div>
    </LanguageProvider>
  );
}
```

#### Private Routes (Authenticated Areas)
```tsx
import { useLanguage } from './langselect';

function PrivateApp() {
  const { t, language, setLanguage } = useLanguage();
  
  return (
    <div className="private-app">
      {/* Top navigation bar */}
      <div className="flex items-center justify-between px-4 py-2">
        <div className="flex items-center space-x-2">
          <MenuToggle />
          <LanguageSelector variant="ghost" size="sm" />
        </div>
        <UserMenu />
      </div>
      
      {/* Content using translations */}
      <main>
        <h1>{t.dashboard.title}</h1>
        <p>{t.dashboard.welcome}</p>
      </main>
    </div>
  );
}
```

## Features

- **Persistent Selection**: Language choice is saved to localStorage
- **Real-time Updates**: Changes apply immediately without page reload
- **Cross-tab Sync**: Language changes sync across browser tabs
- **SEO Friendly**: Updates document language attributes
- **Customizable UI**: Multiple button variants and sizes
- **Type Safety**: Full TypeScript support with translation key validation
- **Flexible Translations**: Easy to add new languages and translation keys

## API Reference

### LanguageProvider Props
- `children`: React components to wrap
- `defaultLanguage`: Initial language (default: 'en')

### LanguageSelector Props
- `className`: Additional CSS classes
- `variant`: Button style ('default' | 'ghost' | 'outline')
- `size`: Button size ('default' | 'sm' | 'lg')

### useLanguage Hook Returns
- `language`: Current language code
- `setLanguage`: Function to change language
- `t`: Translation object with all text strings

## Supported Languages

- English (en) 🇺🇸
- Spanish (es) 🇪🇸  
- French (fr) 🇫🇷
- German (de) 🇩🇪
- Italian (it) 🇮🇹
- Portuguese (pt) 🇵🇹
- Russian (ru) 🇷🇺
- Chinese (zh) 🇨🇳
- Japanese (ja) 🇯🇵
- Korean (ko) 🇰🇷
- Hindi (hi) 🇮🇳

## Adding New Languages

1. Add language to the `languages` array in `components/LanguageSelector.tsx`
2. Add translations in `translations/index.ts`
3. Update the `LanguageStrings` interface in `types.ts`

## Usage Examples

### Basic Usage (Public)
```tsx
import { LanguageProvider, LanguageSelector, useLanguage } from './langselect';

function LandingPage() {
  const { t } = useLanguage();
  
  return (
    <div>
      <header>
        <LanguageSelector />
      </header>
      <main>
        <h1>{t.hero.title}</h1>
        <p>{t.hero.description}</p>
      </main>
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <LandingPage />
    </LanguageProvider>
  );
}
```

### Advanced Usage (Private)
```tsx
function DashboardSettings() {
  const { language, setLanguage, t } = useLanguage();
  
  return (
    <div className="settings-panel">
      <h2>{t.settings.language.label}</h2>
      <p>{t.settings.language.description}</p>
      
      {/* Custom language selector */}
      <select 
        value={language} 
        onChange={(e) => setLanguage(e.target.value)}
      >
        <option value="en">English</option>
        <option value="es">Español</option>
        <option value="fr">Français</option>
      </select>
    </div>
  );
}
```

### Conditional Content
```tsx
function LocalizedContent() {
  const { language, t } = useLanguage();
  
  return (
    <div>
      <h1>{t.welcome}</h1>
      
      {/* Show different content based on language */}
      {language === 'en' && (
        <p>This content is only shown for English users.</p>
      )}
      
      {language === 'es' && (
        <p>Este contenido solo se muestra para usuarios en español.</p>
      )}
    </div>
  );
}
```

## Storage Behavior

- **Storage Key**: `dnsredo-language` (customizable in the hook)
- **Fallback Key**: `selectedLanguage` for compatibility
- **Default Language**: English ('en')
- **Cross-tab Sync**: Uses storage events for real-time updates

## SEO Considerations

The module automatically:
- Sets `document.documentElement.lang` attribute
- Updates `<meta name="language">` tag
- Dispatches custom events for framework integration

## Browser Support

- Modern browsers with ES6+ support
- React 16.8+ (hooks support)
- Works with SSR frameworks like Next.js
- Compatible with React Router and other routing libraries

## Customization

### Custom Button Styles
```tsx
<LanguageSelector 
  className="custom-styles" 
  variant="outline" 
  size="lg" 
/>
```

### Custom Translation Structure
Modify `types.ts` and `translations/index.ts` to match your app's needs.

### Custom Languages
Add new languages by updating the languages array and translation files.

## Integration with Existing Apps

1. **Wrap your app** with `LanguageProvider`
2. **Replace hardcoded text** with `t.key.value` from `useLanguage()`
3. **Add language selector** where appropriate
4. **Test all languages** to ensure proper translation coverage

## License

MIT - Use freely in your projects
