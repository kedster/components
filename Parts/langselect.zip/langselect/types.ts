
export interface Language {
  code: string;
  name: string;
  flag: string;
}

export interface LanguageStrings {
  nav: {
    wiki: string;
    blog: string;
    getStarted: string;
  };
  hero: {
    title: string;
    subtitle: string;
    description: string;
    ctaButton: string;
    noCreditCard: string;
  };
  features: {
    title: string;
    subtitle: string;
    centralizedDns: {
      title: string;
      description: string;
    };
    smartBackups: {
      title: string;
      description: string;
    };
    propagationTracking: {
      title: string;
      description: string;
    };
    aiDnsManagement: {
      title: string;
      description: string;
    };
    teamReady: {
      title: string;
      description: string;
    };
    apiSupport: {
      title: string;
      description: string;
    };
  };
  pricing: {
    title: string;
    subtitle: string;
    freePlan: {
      title: string;
      price: string;
      features: string[];
      button: string;
    };
    premiumPlan: {
      title: string;
      price: string;
      popular: string;
      features: string[];
      button: string;
    };
  };
  app: {
    sidebar: {
      dashboard: string;
      domains: string;
      domainBackups: string;
      dnsRecords: string;
      propagation: string;
      analytics: string;
      aiDrDns: string;
      settings: string;
      help: string;
      pricing: string;
      signOut: string;
    };
    dashboard: {
      title: string;
      totalDomains: string;
      totalRecords: string;
      propagating: string;
      errors: string;
      welcomeBack: string;
    };
    settings: {
      title: string;
      tabs: {
        general: string;
        ai: string;
        dns: string;
        notifications: string;
        security: string;
      };
      general: {
        title: string;
        darkMode: { label: string; description: string };
        autoRefresh: { label: string; description: string };
        refreshInterval: { label: string; description: string };
        language: { label: string; description: string };
        timezone: { label: string };
      };
      ai: {
        title: string;
        description: string;
        managementButton: string;
      };
      dns: {
        title: string;
        defaultTtl: { label: string; description: string };
        propagationMonitoring: {
          title: string;
          configureButton: string;
          description: ({ count }: { count: number }) => string;
        };
      };
      notifications: {
        title: string;
        enableNotifications: { label: string; description: string };
        notificationTypes: {
          title: string;
          dnsChanges: string;
          propagationFailures: string;
          aiRecommendations: string;
          securityAlerts: string;
        };
      };
      security: {
        title: string;
        twoFactor: { label: string; description: string };
        sessionTimeout: { label: string; description: string };
        loginNotifications: { label: string; description: string };
      };
    };
  };
  common: {
    save: string;
    cancel: string;
    delete: string;
    edit: string;
    add: string;
    loading: string;
    error: string;
    success: string;
    confirm: string;
    yes: string;
    no: string;
  };
}

export interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: LanguageStrings;
}

export interface LanguageSelectorProps {
  className?: string;
  variant?: 'default' | 'ghost' | 'outline';
  size?: 'default' | 'sm' | 'lg';
}
